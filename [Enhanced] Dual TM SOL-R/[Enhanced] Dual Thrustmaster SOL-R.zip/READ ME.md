# READ ME

## THESE BINDINGS REQUIRE MY JOYSTICK GREMLIN PROFILE TO WORK

Joystick Gremlin profile included in download.

## Instalation

vJoy Install Video - <https://youtu.be/ugjgKPf1-rk?si=nWBojuAKDvjGu3LO> (Check 3rd video for settings)
HIDHide Install Video - <https://youtu.be/PyL156AywYQ?si=4XSdzWdzmITRkMPi> (Check 3rd video for settings)
Installing Enhanced Binds - <https://youtu.be/mc-ozIogrpI?si=WuwMqg0S-G922i10> (Assumes you have all the programs installed)

## Troubleshooting

Common Enhanced bind issues and their fixes can be found in the FAQ In Discord

- <https://discord.com/channels/303670222097874945/1297919077062279209>

Common joystick/star citizen related issues and their fixes can be found here

- <https://discord.com/channels/303670222097874945/1154143410215731201>

If you have an issue not found in the FAQ, please create a post in the "#vkb-support forum" on discord if your issues isn't in the checklist or FAQ. Please mention a @PeripheralExpert to ensure we are notified ASAP - <https://discord.com/channels/303670222097874945/1006954369800998992>

## Text to Speach & Audio Files

- In the upper right hand corner of JG, you can select which mode you would like to edit. Delete the "Text to Speach" function from button three, on both the left and right sticks. Repeat this for all four modes and save the profile.

- After you remove the TTS If you would like to activate the "play sound" freature you can do so by simply tell JG where to find your audio files. I have added some one I think are cool to a folder included in this package.
- The Salvage and Mining audio files are for those who only mine OR salvage and want to hear a more personalized message. Auxillary is for those who mine or salvage. (This has no effect on the binds.)

## Editable PDF's

The PDF versions are editable in Adobe Illustrator as well as Adobe Acrobat (The paid version, not free).

## Printer Friendly Binding Chart

- The chart labled [PF] has a white backgound to conserve ink for people who would like to print it.

- If you have the paid version of adobe acrobat you can select the "Poster" option in the print settings and change the scale from %100 to 30% and it will spplit the chart into two pages with 1 stick on each page. For other programs just remember that scalled down to 30% its small enough to fit each stick on its own page.
